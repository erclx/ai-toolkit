create table if not exists feeds (
  id         text primary key,
  url        text not null unique,
  kind       text not null check (kind in ('rss', 'atom')),
  label      text not null,
  added_at   integer not null
);

create table if not exists cursor_seen (
  feed_id      text not null references feeds(id) on delete cascade,
  content_hash text not null,
  seen_at      integer not null,
  primary key (feed_id, content_hash)
);

create index if not exists cursor_seen_recency on cursor_seen (feed_id, seen_at desc);

create table if not exists sink_queue (
  id         integer primary key autoincrement,
  sink       text not null,
  payload    text not null,
  attempts   integer not null default 0,
  next_try_at integer not null
);
