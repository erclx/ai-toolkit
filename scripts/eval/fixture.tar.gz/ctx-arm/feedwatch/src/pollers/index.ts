import { atomPoller } from './atom'
import { rssPoller } from './rss'
import type { FeedKind, Poller } from './types'

const registry = new Map<FeedKind, Poller>([
  [rssPoller.kind, rssPoller],
  [atomPoller.kind, atomPoller],
])

export function pollerFor(kind: FeedKind): Poller {
  const poller = registry.get(kind)
  if (!poller) {
    throw new Error(`no poller registered for kind: ${kind}`)
  }
  return poller
}

export function registeredKinds(): FeedKind[] {
  return [...registry.keys()]
}
