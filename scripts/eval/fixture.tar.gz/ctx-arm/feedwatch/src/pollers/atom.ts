import { XMLParser } from 'fast-xml-parser'
import type { FeedItem, Poller } from './types'

const parser = new XMLParser({ ignoreAttributes: false, attributeNamePrefix: '@' })

export const atomPoller: Poller = {
  kind: 'atom',
  async fetchItems(url: string): Promise<FeedItem[]> {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(10_000),
      headers: { accept: 'application/atom+xml, application/xml' },
    })
    if (!response.ok) {
      throw new Error(`atom fetch failed for ${url}: ${response.status}`)
    }

    const doc = parser.parse(await response.text())
    const raw = doc?.feed?.entry ?? []
    const entries = Array.isArray(raw) ? raw : [raw]

    return entries.map((entry) => ({
      title: String(entry.title ?? ''),
      link: String(entry.link?.['@href'] ?? entry.link ?? ''),
      publishedAt: entry.updated ? Date.parse(entry.updated) : null,
      summary: String(entry.summary ?? entry.content ?? ''),
    }))
  },
}
