import { XMLParser } from 'fast-xml-parser'
import type { FeedItem, Poller } from './types'

const parser = new XMLParser({ ignoreAttributes: false })

export const rssPoller: Poller = {
  kind: 'rss',
  async fetchItems(url: string): Promise<FeedItem[]> {
    const response = await fetch(url, {
      signal: AbortSignal.timeout(10_000),
      headers: { accept: 'application/rss+xml, application/xml' },
    })
    if (!response.ok) {
      throw new Error(`rss fetch failed for ${url}: ${response.status}`)
    }

    const doc = parser.parse(await response.text())
    const raw = doc?.rss?.channel?.item ?? []
    const items = Array.isArray(raw) ? raw : [raw]

    return items.map((item) => ({
      title: String(item.title ?? ''),
      link: String(item.link ?? ''),
      publishedAt: item.pubDate ? Date.parse(item.pubDate) : null,
      summary: String(item.description ?? ''),
    }))
  },
}
