export type FeedKind = 'rss' | 'atom'

export interface FeedItem {
  title: string
  link: string
  publishedAt: number | null
  summary: string
}

export interface Poller {
  kind: FeedKind
  fetchItems(url: string): Promise<FeedItem[]>
}
