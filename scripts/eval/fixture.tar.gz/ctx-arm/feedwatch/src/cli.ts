import { Database } from 'bun:sqlite'
import { pollerFor, registeredKinds } from './pollers'
import { drain, enqueue, registeredSinks } from './sinks'
import { filterUnseen, recordSeen } from './store/cursor'

const db = new Database(process.env.FEEDWATCH_DB ?? 'feedwatch.db')

async function pollAll(): Promise<void> {
  const feeds = db
    .query<{ id: string; url: string; kind: 'rss' | 'atom' }, []>(
      'select id, url, kind from feeds'
    )
    .all()

  // Feeds run in parallel, and one broken feed must not abort the cycle.
  await Promise.allSettled(
    feeds.map(async (feed) => {
      const items = await pollerFor(feed.kind).fetchItems(feed.url)
      const fresh = filterUnseen(db, feed.id, items)
      if (fresh.length === 0) {
        return
      }
      enqueue(db, fresh)
      recordSeen(db, feed.id, fresh)
    })
  )

  await drain(db)
}

const command = process.argv[2]

switch (command) {
  case 'poll':
    await pollAll()
    break
  case 'drain':
    await drain(db)
    break
  case 'kinds':
    console.log(registeredKinds().join('\n'))
    break
  case 'sinks':
    console.log(registeredSinks().join('\n'))
    break
  default:
    console.error('usage: feedwatch <poll|drain|kinds|sinks>')
    process.exit(1)
}
