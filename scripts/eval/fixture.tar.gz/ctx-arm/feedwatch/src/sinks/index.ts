import type { Database } from 'bun:sqlite'
import type { FeedItem } from '../pollers/types'
import { emailSink } from './email'
import { webhookSink } from './webhook'
import type { Sink } from './types'

const MAX_ATTEMPTS = 5
const BACKOFF_MS = [30_000, 120_000, 600_000, 3_600_000, 21_600_000]

const sinks = new Map<string, Sink>([
  [webhookSink.name, webhookSink],
  [emailSink.name, emailSink],
])

// Enqueue only. The poll cycle must not await delivery: a webhook endpoint that
// hangs for its full timeout would otherwise stall every later feed in the same
// cycle, and a cycle that runs long enough gets killed by the supervisor before
// it reaches the feeds at the end of the list.
export function enqueue(db: Database, items: FeedItem[]): void {
  const insert = db.query(
    'insert into sink_queue (sink, payload, next_try_at) values (?, ?, ?)'
  )
  for (const item of items) {
    for (const name of sinks.keys()) {
      insert.run(name, JSON.stringify(item), Date.now())
    }
  }
}

export async function drain(db: Database): Promise<void> {
  const due = db
    .query<{ id: number; sink: string; payload: string; attempts: number }, [number]>(
      'select id, sink, payload, attempts from sink_queue where next_try_at <= ? order by id limit 50'
    )
    .all(Date.now())

  // Each row settles on its own. One dead sink must not fail the batch.
  const results = await Promise.allSettled(
    due.map(async (row) => {
      const sink = sinks.get(row.sink)
      if (!sink) {
        throw new Error(`unknown sink: ${row.sink}`)
      }
      await sink.deliver(JSON.parse(row.payload))
      return row.id
    })
  )

  results.forEach((result, index) => {
    const row = due[index]
    if (result.status === 'fulfilled') {
      db.query('delete from sink_queue where id = ?').run(row.id)
      return
    }
    const attempts = row.attempts + 1
    if (attempts >= MAX_ATTEMPTS) {
      db.query('delete from sink_queue where id = ?').run(row.id)
      return
    }
    db.query('update sink_queue set attempts = ?, next_try_at = ? where id = ?').run(
      attempts,
      Date.now() + BACKOFF_MS[attempts - 1],
      row.id
    )
  })
}

export function registeredSinks(): string[] {
  return [...sinks.keys()]
}
