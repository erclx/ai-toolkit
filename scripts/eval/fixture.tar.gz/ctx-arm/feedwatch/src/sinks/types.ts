import type { FeedItem } from '../pollers/types'

export interface Sink {
  name: string
  deliver(item: FeedItem): Promise<void>
}
