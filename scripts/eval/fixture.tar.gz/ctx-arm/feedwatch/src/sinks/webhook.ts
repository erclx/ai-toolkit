import type { FeedItem } from '../pollers/types'
import type { Sink } from './types'

export const webhookSink: Sink = {
  name: 'webhook',
  async deliver(item: FeedItem): Promise<void> {
    const target = process.env.FEEDWATCH_WEBHOOK_URL
    if (!target) {
      throw new Error('FEEDWATCH_WEBHOOK_URL is not set')
    }

    const response = await fetch(target, {
      method: 'POST',
      signal: AbortSignal.timeout(8_000),
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ title: item.title, link: item.link, summary: item.summary }),
    })

    if (!response.ok) {
      throw new Error(`webhook delivery failed: ${response.status}`)
    }
  },
}
