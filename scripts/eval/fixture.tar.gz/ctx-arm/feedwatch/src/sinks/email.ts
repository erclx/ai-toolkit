import type { FeedItem } from '../pollers/types'
import type { Sink } from './types'

export const emailSink: Sink = {
  name: 'email',
  async deliver(item: FeedItem): Promise<void> {
    const key = process.env.FEEDWATCH_SMTP_KEY
    const to = process.env.FEEDWATCH_DIGEST_TO
    if (!key || !to) {
      throw new Error('FEEDWATCH_SMTP_KEY and FEEDWATCH_DIGEST_TO must both be set')
    }

    const response = await fetch('https://api.mailrelay.test/v1/send', {
      method: 'POST',
      signal: AbortSignal.timeout(8_000),
      headers: { authorization: `Bearer ${key}`, 'content-type': 'application/json' },
      body: JSON.stringify({ to, subject: item.title, body: item.summary, link: item.link }),
    })

    if (!response.ok) {
      throw new Error(`email delivery failed: ${response.status}`)
    }
  },
}
