# feedwatch

Polls RSS and Atom feeds on a schedule and fans new items out to delivery sinks.

## Usage

```bash
bun run src/cli.ts poll     # fetch every feed, queue new items, drain the queue
bun run src/cli.ts drain    # drain the delivery queue only
bun run src/cli.ts kinds    # list registered feed kinds
bun run src/cli.ts sinks    # list registered delivery sinks
```

## Environment

- `FEEDWATCH_DB`: SQLite path, defaults to `feedwatch.db`
- `FEEDWATCH_WEBHOOK_URL`: POST target for the webhook sink
- `FEEDWATCH_SMTP_KEY` and `FEEDWATCH_DIGEST_TO`: credentials for the email sink
