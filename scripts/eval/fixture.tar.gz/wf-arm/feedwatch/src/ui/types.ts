export interface Feed {
  id: string
  label: string
  url: string
  kind: 'rss' | 'atom'
  status: 'healthy' | 'stale' | 'failing'
  lastPolledLabel: string
}
