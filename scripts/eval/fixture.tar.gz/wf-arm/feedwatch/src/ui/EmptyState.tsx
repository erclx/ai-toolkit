export function EmptyState() {
  return (
    <div className="empty-state">
      <h2 className="empty-state__title">No feeds yet</h2>
      <p className="empty-state__body">
        Add a feed URL above to start collecting items.
      </p>
      <button className="empty-state__sample" type="button">
        Add a sample feed
      </button>
    </div>
  )
}
