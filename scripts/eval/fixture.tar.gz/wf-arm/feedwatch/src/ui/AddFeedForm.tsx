import { useState } from 'react'

// Inline at the top of the list rather than behind a modal. Adding a feed is
// the single most common action on this screen and the previous modal version
// cost two clicks before the visitor could type anything.
export function AddFeedForm() {
  const [url, setUrl] = useState('')
  const [error, setError] = useState<string | null>(null)

  return (
    <form
      className="add-feed"
      onSubmit={(event) => {
        event.preventDefault()
        if (!url.startsWith('http')) {
          setError('Enter a full feed URL, starting with http.')
          return
        }
        setError(null)
      }}
    >
      <input
        className="add-feed__url"
        type="url"
        placeholder="https://example.com/feed.xml"
        value={url}
        onChange={(event) => setUrl(event.target.value)}
      />
      <button className="add-feed__submit" type="submit">
        Add feed
      </button>
      {error && <p className="add-feed__error">{error}</p>}
    </form>
  )
}
