import { useState } from 'react'
import { AddFeedForm } from './AddFeedForm'
import { FeedRow } from './FeedRow'
import { EmptyState } from './EmptyState'
import type { Feed } from './types'

export function FeedList({ feeds }: { feeds: Feed[] }) {
  const [filter, setFilter] = useState('')

  const visible = feeds.filter((feed) =>
    feed.label.toLowerCase().includes(filter.toLowerCase())
  )

  return (
    <main className="feed-list">
      <header className="feed-list__header">
        <h1>Feeds</h1>
        <p className="feed-list__count">{feeds.length} subscribed</p>
      </header>

      <AddFeedForm />

      <input
        className="feed-list__filter"
        type="search"
        placeholder="Filter feeds"
        value={filter}
        onChange={(event) => setFilter(event.target.value)}
      />

      {feeds.length === 0 ? (
        <EmptyState />
      ) : (
        <ul className="feed-list__rows">
          {visible.map((feed) => (
            <FeedRow key={feed.id} feed={feed} />
          ))}
        </ul>
      )}

      {feeds.length > 0 && visible.length === 0 && (
        <p className="feed-list__no-match">No feeds match “{filter}”.</p>
      )}
    </main>
  )
}
