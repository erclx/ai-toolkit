import type { Feed } from './types'

const STATUS_LABEL: Record<Feed['status'], string> = {
  healthy: 'Healthy',
  stale: 'Stale',
  failing: 'Failing',
}

export function FeedRow({ feed }: { feed: Feed }) {
  return (
    <li className="feed-row">
      <div className="feed-row__main">
        <span className="feed-row__label">{feed.label}</span>
        <span className="feed-row__url">{feed.url}</span>
      </div>

      <span className={`feed-row__kind feed-row__kind--${feed.kind}`}>
        {feed.kind.toUpperCase()}
      </span>

      {/* Below 600px the pill drops its text and renders as a colored dot only.
          The label is duplicated into aria-label so the row stays readable to a
          screen reader at every width. */}
      <span
        className={`feed-row__status feed-row__status--${feed.status}`}
        aria-label={STATUS_LABEL[feed.status]}
      >
        <span className="feed-row__status-text">{STATUS_LABEL[feed.status]}</span>
      </span>

      <span className="feed-row__last-poll">{feed.lastPolledLabel}</span>

      <button className="feed-row__remove" aria-label={`Remove ${feed.label}`}>
        Remove
      </button>
    </li>
  )
}
